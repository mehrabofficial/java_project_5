public class Mathematics implements Gradeable {
    @Override
    public String getGrade() {
        // logic to calculate grade for Mathematics subject
        return "B";
    }
}
