public class Java implements Gradeable {
    @Override
    public String getGrade() {
        // logic to calculate grade for Java subject
        return "A";
    }
}
