public interface Gradeable {
    public String getGrade();
}

